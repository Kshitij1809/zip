package fi.recipie;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RecipieApplication {

	public static void main(String[] args) {
		SpringApplication.run(RecipieApplication.class, args);
	}

}
