package fi.recipie;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RecipieApplicationTests {

	@Test
	void contextLoads() {
	}

}
