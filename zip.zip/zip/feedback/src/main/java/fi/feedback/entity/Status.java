package fi.feedback.entity;

public enum Status {
	PENDING, REVIEWED, RESOLVED

}
