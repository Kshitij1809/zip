package fi.emp.hire;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmpHireApplicationTests {

	@Test
	void contextLoads() {
	}

}
